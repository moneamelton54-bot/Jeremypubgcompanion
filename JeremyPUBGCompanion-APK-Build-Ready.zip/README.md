# Jeremy PUBG Mobile Companion

A black-and-gold Android companion app starter project.

## Features
- Draggable panel inside the companion app (drag the gold title bar).
- Crosshair preview toggle (visual reference only).
- FPS companion-display preference toggle.
- Saved graphics preference.
- Saved sensitivity reference slider.

## Safety and compatibility
This is a standalone companion app. It does not inject code, modify PUBG files, read game memory, automate aiming, or provide cheats. Settings are saved locally on the device. It does not draw over PUBG.

## Build
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated APK will be in `app/build/outputs/apk/debug/`.

For Android-phone-only workflows, Android Studio is not available as a standard Android app; a compatible Gradle build environment or a computer is needed to compile this project.

## Build an APK using GitHub Actions from your Android phone

1. Create a new GitHub repository and upload the contents of this project.
2. Make sure `.github/workflows/android.yml` is included.
3. Open the repository's **Actions** tab.
4. Select **Build Jeremy PUBG Companion APK**.
5. Tap **Run workflow** (or wait for the first push build to finish).
6. Open the completed workflow run and download the `Jeremy-PUBG-Companion-debug` artifact.
7. Extract the downloaded artifact ZIP and open the APK on your Android device to install it.

GitHub may ask you to sign in. Only install APKs you built from source you trust. This debug APK is not a Play Store release.
