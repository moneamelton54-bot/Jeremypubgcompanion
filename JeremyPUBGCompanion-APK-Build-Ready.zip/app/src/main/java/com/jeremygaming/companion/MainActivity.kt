package com.jeremygaming.companion

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.content.Context
import android.graphics.drawable.GradientDrawable
import kotlin.math.max

class MainActivity : Activity() {
    private val gold = Color.rgb(217, 174, 66)
    private val bg = Color.rgb(9, 9, 9)
    private val panelBg = Color.rgb(24, 24, 24)
    private lateinit var content: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("companion_settings", Context.MODE_PRIVATE)

        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            setPadding(18, 24, 18, 18)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panelBg, 22)
            setPadding(18, 18, 18, 18)
        }
        val params = FrameLayout.LayoutParams(
            dp(330), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = dp(35) }
        root.addView(content, params)
        setContentView(root)
        showHome()
    }

    private fun showHome() {
        content.removeAllViews()
        val header = TextView(this).apply {
            text = "♛  JEREMY PUBG MOBILE"
            textSize = 21f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 4)
        }
        content.addView(header)
        label("ULTIMATE GAMING COMPANION", 11f, Color.LTGRAY)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("HOME", "CROSSHAIR", "GRAPHICS", "SENSITIVITY").forEach { name ->
            val b = Button(this).apply {
                text = name
                textSize = 9f
                setTextColor(gold)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { when(name) {
                    "HOME" -> showHome()
                    "CROSSHAIR" -> showCrosshair()
                    "GRAPHICS" -> showGraphics()
                    else -> showSensitivity()
                } }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        content.addView(tabs)
        divider()
        addSwitch("Crosshair preview", "crosshair", true)
        addSwitch("FPS display in companion", "fps", true)
        label("These are companion-app settings. They do not change PUBG or automate gameplay.", 12f, Color.LTGRAY)
        divider()
        label("JEREMY GAMING  •  ANDROID EDITION", 10f, gold)
        label("Tip: Drag the gold title bar to move this panel.", 11f, Color.LTGRAY)
        header.setOnTouchListener(DragTouchListener(content))
    }

    private fun showCrosshair() {
        simplePage("CROSSHAIR PREVIEW") {
            val preview = TextView(this).apply {
                text = "       ─  │  ─\n             +\n       ─  │  ─"
                textSize = 25f
                setTextColor(gold)
                gravity = Gravity.CENTER
                setPadding(8, 28, 8, 28)
                background = rounded(Color.rgb(15,15,15), 14)
            }
            content.addView(preview)
            addSwitch("Show preview in companion", "crosshair", true)
        }
    }

    private fun showGraphics() {
        simplePage("GRAPHICS PREFERENCE") {
            val options = listOf("Smooth", "Balanced", "Quality")
            val spinner = Spinner(this)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
            spinner.setSelection(options.indexOf(prefs.getString("graphics", "Balanced")).coerceAtLeast(0))
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putString("graphics", options[position]).apply()
                }
            }
            content.addView(spinner)
            label("A saved recommendation only. Change graphics inside PUBG settings.", 12f, Color.LTGRAY)
        }
    }

    private fun showSensitivity() {
        simplePage("SENSITIVITY REFERENCE") {
            val value = TextView(this).apply {
                textSize = 26f; setTextColor(gold); gravity = Gravity.CENTER
                text = prefs.getInt("sensitivity", 65).toString()
            }
            content.addView(value)
            val seek = SeekBar(this).apply {
                max = 100
                progress = prefs.getInt("sensitivity", 65)
                progressTintList = android.content.res.ColorStateList.valueOf(gold)
                thumbTintList = android.content.res.ColorStateList.valueOf(gold)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) {
                        value.text = p.toString()
                        prefs.edit().putInt("sensitivity", p).apply()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            content.addView(seek)
            label("Personal note/reference only. It is not applied to the game.", 12f, Color.LTGRAY)
        }
    }

    private fun simplePage(title: String, body: () -> Unit) {
        content.removeAllViews()
        val heading = TextView(this).apply {
            text = "♛  $title"
            textSize = 18f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(4, 12, 4, 18)
        }
        content.addView(heading)
        body()
        val back = Button(this).apply {
            text = "BACK TO HOME"; setTextColor(gold); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showHome() }
        }
        content.addView(back)
        heading.setOnTouchListener(DragTouchListener(content))
    }

    private fun addSwitch(title: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 8)
        }
        val text = TextView(this).apply { this.text = title; textSize = 14f; setTextColor(Color.WHITE) }
        val toggle = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            buttonTintList = android.content.res.ColorStateList.valueOf(gold)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        row.addView(text, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(toggle)
        content.addView(row)
    }

    private fun label(value: String, size: Float, color: Int) {
        content.addView(TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER; setPadding(4, 8, 4, 8)
        })
    }

    private fun divider() {
        content.addView(View(this).apply { setBackgroundColor(gold) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(8) })
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), gold)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(view: View) : View.OnTouchListener {
        private var startX = 0f
        private var startY = 0f
        private var initialX = 0
        private var initialY = 0
        private val target = view
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = target.layoutParams as FrameLayout.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = lp.leftMargin; initialY = lp.topMargin
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.leftMargin = initialX + (event.rawX - startX).toInt()
                    lp.topMargin = max(dp(8), initialY + (event.rawY - startY).toInt())
                    target.layoutParams = lp
                    return true
                }
            }
            return true
        }
    }
}
